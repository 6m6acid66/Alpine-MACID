# MACID OS

**MACID OS is an independent x86_64 Linux distribution built on Alpine Linux.**

This repository is being rebuilt on Alpine's own image tooling. It is not a Kali remaster and does not use Kali Live Build, Debian, or APT.

## Foundation

- Base: Alpine Linux 3.24.x
- Architecture: x86_64
- Image builder: Alpine's official `aports/scripts/mkimage.sh`
- Init/service manager: OpenRC
- Package manager: APK
- Initial shell: BusyBox ash, with Zsh included in the ISO's local package repository
- Boot: BIOS/UEFI hybrid ISO
- Build: GitHub Actions, inside an Alpine build container

## First milestone

1. Build a real Alpine-based bootable ISO.
2. Give the boot menu and live system MACID identity.
3. Add the first `macid` command with help, version, status, and identity.
4. Verify that the ISO contains the Alpine kernel, initramfs, and MACID overlay.
5. Boot the ISO in QEMU before writing anything to a physical drive.

The first image is a minimal live foundation, not the finished desktop release. The MACID desktop, Control Center, additional tools, and installer work follow only after the base image boots and passes verification.

## Build

Run the **Build MACID OS (Alpine)** workflow from GitHub Actions, or push a change to the build paths on `main`.

The workflow uses Alpine's official 3.24-stable aports tree and the Alpine mkimage framework. It creates a temporary signing key for the local APK index; no private release key is stored in the repository.

## Verification rule

A successful CI job is not proof that the OS boots. The ISO must pass structural checks and then boot in QEMU. Do not write it to a USB drive until that test succeeds.

## Repository layout

- `build/mkimg.macid.sh`: MACID image profile and boot-menu identity
- `build/genapkovl-macid.sh`: live-system MACID identity overlay
- `.github/workflows/build.yml`: Alpine-only build and ISO checks
- `boot/`: retained legacy artwork/configuration, to be integrated after the foundation is verified

## Current status

Foundation build in progress. No ISO is declared boot-tested until QEMU verification is complete.
